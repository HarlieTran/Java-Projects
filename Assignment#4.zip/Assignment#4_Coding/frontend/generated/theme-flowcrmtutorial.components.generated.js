


if (!document['_vaadintheme_flowcrmtutorial_componentCss']) {
  
  document['_vaadintheme_flowcrmtutorial_componentCss'] = true;
}

if (import.meta.hot) {
  import.meta.hot.accept((module) => {
    window.location.reload();
  });
}

