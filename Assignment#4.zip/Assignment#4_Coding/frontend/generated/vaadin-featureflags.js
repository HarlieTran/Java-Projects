// @ts-nocheck
window.Vaadin = window.Vaadin || {};
window.Vaadin.featureFlags = window.Vaadin.featureFlags || {};
window.Vaadin.featureFlags.exampleFeatureFlag = false;
window.Vaadin.featureFlags.collaborationEngineBackend = false;
window.Vaadin.featureFlags.webPush = false;
window.Vaadin.featureFlags.formFillerAddon = false;
window.Vaadin.featureFlags.reactRouter = false;
export {};